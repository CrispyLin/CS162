/******************************************************
** Program: Go_Fish.cpp
** Author: Xinwei Lin
** Date: 07/10/2020
** Description: A go fish game
** Input: 0-10 numbers and A J K Q
** Output: Cards, books
******************************************************/
#include <iostream>
#include <string>
#include <stdlib.h>
#include <string.h>
#include "Card.h"
#include "Deck.h"
#include "Hand.h"
#include "Player.h"
#include "Game.h"
using namespace std;


bool check_commandline(int argc, char** argv){
	if(argc != 2){
		cout<<"Error!\nUsage: ./go_fish false  or  ./go_fish true"<<endl;
		exit(1);
	}
	if(argv[1][0] == 't')
		return true;
	else
		return false;
}


void cheat_view(Game* game){
	while (!(*game).is_game_over()) {
		while (1) {
			if (!((*game).user_round_cheat())) {
				break;
			}
		}

		while (1) {
			if (!((*game).computer_round())) {
				break;
			}
		}
	}
}

void normal_view(Game* game){
	while (!(*game).is_game_over()) {
		while (1) {
			if (!((*game).user_round())) {
				break;
			}
		}

		while (1) {
			if (!((*game).computer_round())) {
				break;
			}
		}
	}
}

//if user want to play again, the function will return true, vice versa.
bool again(){
	cout<<"Do you want to play again? (1 for yes, 0 for no) ";
	string input;
	do{
		getline(cin, input);
		if(input=="1")
			return true;
		else if(input=="0")
			return false;
		else{
			cout<<"Error, please type 1 or 0: ";
		}
	}while(1);
}

int main(int argc, char** argv) {
	srand(time(NULL));
	bool mode = check_commandline(argc, argv);
	bool go_again = true;
	while(go_again){
		cout << "Welcome to the game Go fish, today your opponent is Carlos, enjoy!\n" << endl;
		Game game;
		game.set_up();
		if(mode)
			cheat_view(&game);//user typed true
		else
			normal_view(&game);//user typed false
		game.calculate_results();
		go_again = again();
	}
	cout<<"Bye!"<<endl;
	return 0;
}
