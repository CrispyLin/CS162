Name: Xinwei Lin
onid: linxinw

Description: nothing, just do want the program is asking. I handled all errors.

Instructions: 
	compile:
		make
	run:
		./prog true
		./prog false

Limitations:
	no

Extra Credit:
	no